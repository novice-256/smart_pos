import { Component, signal } from '@angular/core';
import { RouterOutlet ,RouterLink} from '@angular/router';
import { Home } from './home/home';
@Component({
  selector: 'app-root',
  imports: [ RouterLink,RouterOutlet ],
  templateUrl: './app.html',
  styleUrl: './app.css',

})
export class App {
  protected title = signal('learn-angular');
  protected name = 'jahangir shah';
   age = new Date().getFullYear() - 1994  ;
  //  welcome(){
  //   alert(`hello ${this.name}\n Your age is ${this.age}`);
  //  }
   users = [ 'adam' , 'ali' , 'akram' , 'kamran'];
}
